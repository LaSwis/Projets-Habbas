package Vue;

public interface InterfaceUtilisateur {
	void jouePartie();
	void Configuration();

}
