package Modele;

public abstract class Commande {
    abstract void Execute();

    abstract void DesExecute();
}
