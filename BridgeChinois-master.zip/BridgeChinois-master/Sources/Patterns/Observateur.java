package Patterns;

public interface Observateur {
	void metAJour();
}
